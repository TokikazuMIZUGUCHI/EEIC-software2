intは4バイト、doubleは８バイト、charは1バイトアライメントである

- student  
ageのあとに４バイト分のパディングが挿入されている。

- tagged_student1  
 age-heightの間には4バイト、tagの後には7バイトのパディングが挿入されている。

 - tagged student2
 tagの後に3バイトぶんのパディングが挿入されている。
 