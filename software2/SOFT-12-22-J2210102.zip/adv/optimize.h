#ifndef OPTIMIZE_OPTIMIZE_H
#define OPTIMIZE_OPTIMIZE_H
#include "func.h"

int optimize(const double alpha, const int dim, double x[],
             void (*calc_grad)(const double [], double [], Sample data[], int n), double (*calc_value)(const double [], Sample data[], int n), Sample data[], int n);

#endif
